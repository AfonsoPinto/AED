
public class Main {

	public static void main(String[] args) {
		
		LinkedList nums = new LinkedList();
		nums.enqueue(7);
		nums.enqueue(11);
		nums.enqueue(3);
		
		nums.goThrough();  
	
		
		nums.find(7);
		nums.find(3);
		nums.find(23);
		nums.find(11);
		nums.find(6);
		
		nums.dequeue(11);
		nums.goThrough();
		
		nums.dequeue(7);
		nums.goThrough();
		
		nums.dequeue(3);
		nums.goThrough();
	}

}
