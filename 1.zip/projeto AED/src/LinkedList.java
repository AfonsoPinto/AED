
public class LinkedList {

	int size = 0;
	Node head;
	Node tail;

	public void enqueue(int number) {

		// no caso de haver um elemento na fila, este � simultaneamente a head
		// e a tail.

		Node node = new Node(number);
		if (head == null) {
			tail = node;
			head = node;
		} else {
			head.next = node;
			head = node;
		}
		size++;

	}

	public Node find(int number) {
		if (head == null) 
			return null;
		
		 if (head.number == number)
			return head;
		
		Node node = head;

		while (node.next != null) {
			node = node.next;
			if (node.number == number) 
				return node;
			}
			return null;
		}

	

	public Node findNodeBefore(int number) {

		// o number est� na head da LinkedList
		if (head.number == number) 
			return new Node();
		
		Node node = head;

		while (node.next != null) {
			if (node.next.number == number) 
				return node;
			
			node = node.next;}
			if (node.number == number) {
				return node;
			}
			return null;
		}
	

	public Node dequeue(int number) {
		Node nodeToReturn = null;

		if (size == 0) {
			return null;
		}
		if (size == 1) {
			nodeToReturn = head;
			head = null;
			tail = null;
			size--;
			return nodeToReturn;
		}

		Node nodeBeforeNodeToDelete = findNodeBefore(number);

		// apagar a head
		if (nodeBeforeNodeToDelete.number == 0) {
			head = head.next;
			size--;
		} else if (nodeBeforeNodeToDelete != null) {

			if (tail.number == number) {
				nodeBeforeNodeToDelete.next = null;
				tail = nodeBeforeNodeToDelete;
			} else {
				nodeBeforeNodeToDelete.next = nodeBeforeNodeToDelete.next.next;
			}

		}
		if (tail == nodeBeforeNodeToDelete) {

		}
		size--;
		return null;

	}

	// m�todo para percorrer a fila do in�cio ao fim
	public void goThrough() {
		if (head != null) {
			Node node = head;
			while (node.next != null) {
				node = node.next;
			}
		}
	}
}
