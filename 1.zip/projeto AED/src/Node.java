
public class Node {
	
 int number;
 Node next;
	
public Node(int number){
	this.number = number;
}

public Node() {
	
}

@Override
public String toString() {
	return String.valueOf(number); // ou usa-se  "" + number;
	}


	
}
	
	


